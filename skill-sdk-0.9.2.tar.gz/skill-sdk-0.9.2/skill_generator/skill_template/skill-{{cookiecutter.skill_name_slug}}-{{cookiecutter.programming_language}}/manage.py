#!/usr/bin/env python
from skill_sdk.manage import manage

manage()
