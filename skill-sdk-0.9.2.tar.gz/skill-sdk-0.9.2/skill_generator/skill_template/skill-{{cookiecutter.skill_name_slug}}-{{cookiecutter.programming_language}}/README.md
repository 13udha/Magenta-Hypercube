# Skill {{cookiecutter.skill_name}} - {{cookiecutter.programming_language}}

## Samples

### Hello

This implementation returns "Hello" greeting to user saying "Hello". 

### Chuck Norris Jokes

This implementation returns a random joke from Chuck Norris jokes database: http://api.icndb.com/jokes/random

### Guess the Number Game

This is a sample implementation of "Guess the Number" game. User says a number and we answer if they got it right or not.
